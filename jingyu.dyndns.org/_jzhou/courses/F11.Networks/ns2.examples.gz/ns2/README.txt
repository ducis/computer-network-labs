simple_network.tcl
	A two-node topology graph.

cbr.tcl
	CBR UDP flow between two nodes.

2cbr.tcl
	2 CBR UDP flow interferes with each other. See packet drops.2cbr.tcl

ns-simple.tcl
	CBR UDP flow interferes with FTP/TCP flow. See TCP packet drop resulting in
	slow start.

ns-simple-trace.tcl
	Same as the above, but produce "out.tr" trace file.
	Run create_jitter.sh to produce jitter.txt as output.
	Run gnuplot	
gnuplot> set xrange [0:600]
gnuplot> set yrange [0:0.02]
gnuplot> plot 'jitter.txt' using 1:2 with lines
gnuplot> plot 'jitter.txt' using 1:2 with lines title 'CBR jitter at Node n3'
gnuplot> set xlabel 'Sequence #'
gnuplot> set ylabel 'Delay'
gnuplot> set term postscript colour
gnuplot> set output 'jitter.eps'


