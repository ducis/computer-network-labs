#include "networking.h"

#define SERVERPORT  8000
#define LISTENQSIZE 5

extern  uint16_t serverport;
extern  uint16_t listenqsize;
