#include	"server.h"

/* global variables */
int      debug;
uint16_t serverport;
uint16_t listenqsize;
char     wwwroot[MAXLINE];

static void
initialize_parameters(void) 
{
  serverport  = SERVERPORT;
  listenqsize = LISTENQSIZE; 
  debug = 0;
  strcpy(wwwroot, WWWROOT);
}

static void
usage(char *program)
{
  fprintf(stderr, "usage: %s [-port port] [-listenq qsize] [-wwwroot dir] [-debug]\n", program);
  exit(1);
}

static void
parse_args(int argc, char** argv) 
{
  int n = 1;
  while (n < argc) {
    if (strcmp(argv[n], "-debug") == 0) {
      debug = 1;
    } else if (strcmp(argv[n], "-port") == 0) {
      serverport = atoi(argv[++n]);
    } else if (strcmp(argv[n], "-listenq") == 0) {
      listenqsize = atoi(argv[++n]);
    } else if (strcmp(argv[n], "-wwwroot") == 0) {
      strcpy(wwwroot,argv[++n]);
    } else
      usage(argv[0]);
    n++;
  }
}

int
main(int argc, char **argv)
{
  int                 listenfd, connectionfd;
  struct sockaddr_in  clientsockaddr, serversockaddr;
  socklen_t	      clientsocklen;

  // initialize setup parameters such as server port number, debug
  initialize_parameters();

  // parse args, to overwrite the parameters
  parse_args(argc, argv);

  // setup signal handler for SIGCHLD to avoid zombie children
  signal(SIGCHLD, sig_child);
  // setup signal handler for other signals
  signal(SIGTERM, sig_term);
  signal(SIGINT,  sig_int);
  signal(SIGHUP,  sig_hup);
  signal(SIGUSR1, sig_usr1);
  signal(SIGPIPE, SIG_IGN);

  // create listening socket
  if ( (listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    err_sys("socket error");
  }

  // fill in and bind address
  bzero(&serversockaddr, sizeof(serversockaddr));
  serversockaddr.sin_family      = AF_INET;
  serversockaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  serversockaddr.sin_port        = htons(serverport);
  if (bind(listenfd, (SA *) &serversockaddr, sizeof(serversockaddr)) < 0)
    err_sys("bind error");

  // enter listen state
  if (listen(listenfd, listenqsize) < 0)
    err_sys("listen error");


  // start to accept requests, spawn a new child for each request
  for ( ; ; ) {
    clientsocklen = sizeof(clientsockaddr);
    if ( (connectionfd = accept(listenfd, (SA *) &clientsockaddr, &clientsocklen)) < 0) {
      if (errno == EINTR)
	continue;		/* back to for() */
      else
	err_sys("accept error");
    }
    
    process_one_request(listenfd, connectionfd);
  }
}

