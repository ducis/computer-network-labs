#include "networking.h"

#ifndef __http_h
#define _http_h

char* get_mime_type(char *filename);
char *get_status_text(int status);
void  generate_http_common_response_headers(socketstream *ss);
void  http_error(int status, socketstream *ss);

#endif /* __http_h */
