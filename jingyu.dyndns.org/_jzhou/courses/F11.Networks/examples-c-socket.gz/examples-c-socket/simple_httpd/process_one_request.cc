#include "server.h"
#include "http.h"

void
process_one_request(int sockfd)
{
  int  linelen;
  char line[MAXLINE];
  char method[MAXLINE], url[MAXLINE], protocol[MAXLINE];
  char *filename;

  socketstream ss(sockfd);

  // first change to the current directory
  // you can change
  if ( chdir(wwwroot) < 0) {
    if (debug) cerr << "Cannot change to " << wwwroot << endl;
    http_error(500, &ss);
  }

  /*
   * start processing request 
   */
  // read in the request line
  if ( (linelen=ss.read_line(line, sizeof(line))) <= 0) {
    if (debug) cerr << "Cannot read request line" << endl;
    http_error(400, &ss);
  }
  if (sscanf(line, "%[^ ] %[^ ] %[^ ]", method, url, protocol) != 3) {
    if (debug) cerr << "Request line format incorrect" << endl;
    http_error(400, &ss);
  }
  // check if url is valid
  struct stat filestatus;
  filename = &url[1];
  if (stat(filename, &filestatus) < 0) {
    if (debug) cerr << "URL: " << url << " is not valid" << endl;
    http_error(400, &ss);
  }
  
  // parse the header lines
  while (linelen > 0) {
    linelen=ss.read_line(line, sizeof(line));
  }
  if (linelen <0) { // error
    if (debug) cerr << "Socket read error" << endl;
    http_error(400, &ss);
  }


  /* 
   * Now, if no error and we do need to send the file, we need to start
   * check if we can read the file before we determine the file status code
   */
  FILE *fp = fopen(filename, "r");
  if (fp == (FILE*) 0) { // we cannot read the file
    if (debug) cerr << "File read denied" << endl;
    http_error(403, &ss);
  }

  // Now we can output the file
  ss.snprintf_buf("HTTP/1.0 %d%s\r\n", 200, get_status_text(200));
  ss.snprintf_buf("Content-type: %s\r\n\r\n", get_mime_type(url));
  ss.flush_buf();

  char fbuf[MAXBUF];
  int n;
  while( (n=fread(fbuf, 1, MAXBUF, fp)) > 0) { 
    ss.writen_socket(fbuf, n);
  }
  
  fclose(fp);
  close(sockfd);
}

