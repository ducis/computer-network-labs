#include	"server.h"

void *process_one_http_request(void *connectionfd);

void process_one_request(int listenfd, int connectionfd) 
{
  pid_t		      childpid;   
  if ( (childpid = fork()) == 0) {	/* child process */
    close(listenfd);	                /* close listening socket */
    process_one_http_request((void *)connectionfd);/* process the request */
    /* connectionfd will be closed by process_one_http_request */
    exit(0);
  } else {
    close(connectionfd);		/* parent closes connected socket */
  }
}

