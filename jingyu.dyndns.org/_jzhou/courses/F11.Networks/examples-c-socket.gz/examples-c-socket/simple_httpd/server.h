#include "networking.h"

#define SERVERPORT  8000
#define LISTENQSIZE 5
#define WWWROOT     "."

extern  uint16_t serverport;
extern  uint16_t listenqsize;
extern  char     wwwroot[]; 

void process_one_request(int listenfd, int connectionfd);
