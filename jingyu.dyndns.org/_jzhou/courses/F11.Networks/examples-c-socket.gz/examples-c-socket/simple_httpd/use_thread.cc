#include "server.h"
#include <pthread.h>

void *process_one_http_request(void *connectionfd);

void process_one_request(int listenfd, int connectionfd) 
{
  pthread_t  tid;
  if (pthread_create(&tid, NULL, process_one_http_request, (void *) connectionfd)) {
    err_quit("pthread_creat()");
  }
}

