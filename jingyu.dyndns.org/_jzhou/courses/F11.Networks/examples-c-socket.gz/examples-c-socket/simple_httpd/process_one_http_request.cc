#include "server.h"
#include "http.h"

using std::cerr;
using std::endl;

void *
process_one_http_request(void *connectionfd)
{
  int  linelen;
  char line[MAXLINE];
  char method[MAXLINE], url[MAXLINE], protocol[MAXLINE];
  char *filename;

  int sockfd = (int) connectionfd;

  if (debug) cerr << "connection socket " << sockfd << endl;

  socketstream ss(sockfd);

  // first change to the current directory
  // you can change
  if ( chdir(wwwroot) < 0) {
    if (debug) cerr << "Cannot change to " << wwwroot << endl;
    http_error(500, &ss);
  }

  /*
   * start processing request 
   */
  // read in the request line
  if ( (linelen=ss.read_line(line, sizeof(line))) <= 0)
    http_error(400, &ss);

  if (sscanf(line, "%[^ ] %[^ ] %[^ ]", method, url, protocol) != 3)
    http_error(400, &ss);

  // check if url is valid
  struct stat filestatus;
  filename = &url[1];
  if (stat(filename, &filestatus) < 0) {
    if (debug) cerr << "URL: " << url << " is not valid" << endl;
    http_error(400, &ss);
  }
  
  // parse the header lines
  while ( (linelen=ss.read_line(line, sizeof(line))) > 0) {
    // check for empty line
    if ((line[0] == '\n') || ((line[0] == '\r') && (line[1] == '\n')))
	break;
    // process a head line here
  }

  if (linelen <= 0) { // We do not find an empty line
    if (debug) cerr << "Socket read error" << endl;
    http_error(400, &ss);
  }

  /* 
   * Now, if no error and we do need to send the file, we need to start
   * check if we can read the file before we determine the file status code
   */
  FILE *fp = fopen(filename, "r");
  if (fp == (FILE*) 0) // we cannot read the file
    http_error(403, &ss);

  // Now we can output the file
  ss.snprintf_buf("HTTP/1.0 %d%s\r\n", 200, get_status_text(200));
  ss.snprintf_buf("Content-type: %s\r\n\r\n", get_mime_type(url));
  ss.flush_buf();

  char fbuf[MAXBUF];
  int n;
  while( (n=fread(fbuf, 1, MAXBUF, fp)) > 0) { 
    ss.writen_socket(fbuf, n);
  }
  
  fclose(fp);
  close(sockfd);

  return NULL; // not used
}

