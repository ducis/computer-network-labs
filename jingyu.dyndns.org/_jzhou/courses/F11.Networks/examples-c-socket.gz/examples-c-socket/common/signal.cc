/*
 * Defines functions related with signals
 */
#include "networking.h"

/* process terminated children to avoid zombie */
void
sig_child(int signo)
{
  pid_t	pid;
  int	stat;
  
  while ( (pid = waitpid(-1, &stat, WNOHANG)) > 0)
    printf("child %d terminated\n", pid);
  return;
}

/* you can can the hup signal to wake a server to reread its configuration */
void
sig_hup(int signo)
{
  return;
}

/* default to handle the termination signals */
void
sig_term(int signo)
{
  exit(0);
}

/* default to handle the interupt signal */
void
sig_int(int signo)
{
  exit(0);
}

/* default to handle the user defeined urs signal */
void
sig_usr1(int signo)
{
  return;
}

/*
 * redefine the function to set signal by using sigaction to improve
 * portability
 */
Sigfunc *
signal(int signo, Sigfunc *func)
{
  struct sigaction	act, oact;

  act.sa_handler = func;
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;
  if (signo == SIGALRM) {
#ifdef	SA_INTERRUPT
    act.sa_flags |= SA_INTERRUPT;	/* SunOS 4.x */
#endif
  } else {
#ifdef	SA_RESTART
    act.sa_flags |= SA_RESTART;		/* SVR4, 44BSD */
#endif
  }
  if (sigaction(signo, &act, &oact) < 0)
    return(SIG_ERR);
  return(oact.sa_handler);
}

Sigfunc *
Signal(int signo, Sigfunc *func)	/* for our signal() function */
{
  Sigfunc	*sigfunc;
  
  if ( (sigfunc = signal(signo, func)) == SIG_ERR)
    err_sys("signal error");
  return(sigfunc);
}
